//! CLAP `clap_entry`. `get_factory` returns a plugin factory whose
//! `create_plugin` builds an `AudioGridder`.

use std::ffi::{c_char, c_void};

use openplugin::prelude::Plugin;

const PLUGIN_ID: &[u8] = b"com.opengrid.audiogridder";
const FACTORY_ID: &[u8] = b"clap.plugin-factory";
const CLAP_PROCESS_CONTINUE: i32 = 1;
const CLAP_PROCESS_ERROR: i32 = 0;

#[repr(C)]
struct ClapVersion {
    major: u32,
    minor: u32,
    revision: u32,
}

#[repr(C)]
pub(crate) struct ClapPluginEntry {
    clap_version: ClapVersion,
    init: extern "C" fn(*const c_char) -> bool,
    deinit: extern "C" fn(),
    get_factory: extern "C" fn(*const c_char) -> *const c_void,
}

#[repr(C)]
struct ClapPluginDescriptor {
    clap_version: ClapVersion,
    id: *const c_char,
    name: *const c_char,
    vendor: *const c_char,
    url: *const c_char,
    manual_url: *const c_char,
    support_url: *const c_char,
    version: *const c_char,
    description: *const c_char,
    features: *const *const c_char,
}

#[repr(C)]
struct ClapPlugin {
    desc: *const ClapPluginDescriptor,
    plugin_data: *mut c_void,
    init: extern "C" fn(*const ClapPlugin) -> bool,
    destroy: extern "C" fn(*const ClapPlugin),
    activate: extern "C" fn(*const ClapPlugin, f64, u32, u32) -> bool,
    deactivate: extern "C" fn(*const ClapPlugin),
    start_processing: extern "C" fn(*const ClapPlugin) -> bool,
    stop_processing: extern "C" fn(*const ClapPlugin),
    reset: extern "C" fn(*const ClapPlugin),
    process: extern "C" fn(*const ClapPlugin, *const ClapProcess) -> i32,
    get_extension: extern "C" fn(*const ClapPlugin, *const c_char) -> *const c_void,
    on_main_thread: extern "C" fn(*const ClapPlugin),
}

#[repr(C)]
struct ClapPluginFactory {
    get_plugin_count: extern "C" fn(*const ClapPluginFactory) -> u32,
    get_plugin_descriptor:
        extern "C" fn(*const ClapPluginFactory, u32) -> *const ClapPluginDescriptor,
    create_plugin:
        extern "C" fn(*const ClapPluginFactory, *const c_void, *const c_char) -> *const ClapPlugin,
}

#[repr(C)]
struct ClapProcess {
    steady_time: i64,
    frames_count: u32,
    transport: *const c_void,
    audio_inputs: *const ClapAudioBuffer,
    audio_outputs: *mut ClapAudioBuffer,
    audio_inputs_count: u32,
    audio_outputs_count: u32,
    in_events: *const c_void,
    out_events: *const c_void,
}

#[repr(C)]
struct ClapAudioBuffer {
    data32: *mut *mut f32,
    data64: *mut *mut f64,
    channel_count: u32,
    latency: u32,
    constant_mask: u64,
}

#[repr(C)]
struct ClapLatency {
    get: extern "C" fn(*const ClapPlugin) -> u32,
}

#[repr(C)]
struct ClapAudioPortInfo {
    id: u32,
    name: [u8; 256],
    flags: u32,
    channel_count: u32,
    port_type: *const c_char,
    in_place_pair: u32,
}

#[repr(C)]
struct ClapAudioPorts {
    count: extern "C" fn(*const ClapPlugin, bool) -> u32,
    get: extern "C" fn(*const ClapPlugin, u32, bool, *mut ClapAudioPortInfo) -> bool,
}

struct ClapOwned {
    clap: ClapPlugin,
    plugin: ag_plugin::AudioGridder,
    scratch: [Vec<f32>; 2],
    prepared: usize,
    active: bool,
}

const _: () = assert!(std::mem::offset_of!(ClapPluginEntry, init) == 16);
const _: () = assert!(std::mem::offset_of!(ClapPluginDescriptor, id) == 16);
const _: () = assert!(std::mem::size_of::<ClapProcess>() == 64);
const _: () = assert!(std::mem::size_of::<ClapAudioBuffer>() == 32);

const fn lit(bytes: &[u8]) -> *const c_char {
    bytes.as_ptr() as *const c_char
}

#[repr(C)]
struct FeatureList {
    items: [*const c_char; 4],
}

unsafe impl Sync for FeatureList {}
unsafe impl Sync for ClapPluginDescriptor {}

static ID: &[u8] = b"com.opengrid.audiogridder\0";
static NAME: &[u8] = b"AudioGridder\0";
static VENDOR: &[u8] = b"OpenGrid\0";
static URL: &[u8] = b"https://opengrid.studio\0";
static VERSION: &[u8] = b"2.0.0-alpha.1\0";
static BLANK: &[u8] = b"\0";
static DESCRIPTION: &[u8] = b"AudioGridder remote insert\0";
static FEATURE_EFFECT: &[u8] = b"audio-effect\0";
static FEATURE_STEREO: &[u8] = b"stereo\0";
static FEATURE_UTILITY: &[u8] = b"utility\0";
static PORT_STEREO: &[u8] = b"stereo\0";

static FEATURES: FeatureList = FeatureList {
    items: [
        lit(FEATURE_EFFECT),
        lit(FEATURE_STEREO),
        lit(FEATURE_UTILITY),
        std::ptr::null(),
    ],
};

static DESCRIPTOR: ClapPluginDescriptor = ClapPluginDescriptor {
    clap_version: ClapVersion {
        major: 1,
        minor: 2,
        revision: 6,
    },
    id: lit(ID),
    name: lit(NAME),
    vendor: lit(VENDOR),
    url: lit(URL),
    manual_url: lit(BLANK),
    support_url: lit(BLANK),
    version: lit(VERSION),
    description: lit(DESCRIPTION),
    features: FEATURES.items.as_ptr(),
};

static FACTORY: ClapPluginFactory = ClapPluginFactory {
    get_plugin_count: factory_count,
    get_plugin_descriptor: factory_descriptor,
    create_plugin: factory_create,
};

static LATENCY_EXT: ClapLatency = ClapLatency { get: latency_get };
static PORTS_EXT: ClapAudioPorts = ClapAudioPorts {
    count: ports_count,
    get: ports_get,
};

extern "C" fn entry_init(_path: *const c_char) -> bool {
    let facts = crate::facts();
    let _ = (facts.id, facts.latency, facts.version);
    true
}

extern "C" fn entry_deinit() {}

extern "C" fn entry_get_factory(factory_id: *const c_char) -> *const c_void {
    if crate::cstr_eq(factory_id, FACTORY_ID) {
        let _ = crate::facts();
        &FACTORY as *const ClapPluginFactory as *const c_void
    } else {
        std::ptr::null()
    }
}

extern "C" fn factory_count(_factory: *const ClapPluginFactory) -> u32 {
    1
}

extern "C" fn factory_descriptor(
    _factory: *const ClapPluginFactory,
    index: u32,
) -> *const ClapPluginDescriptor {
    if index == 0 {
        &DESCRIPTOR
    } else {
        std::ptr::null()
    }
}

extern "C" fn factory_create(
    _factory: *const ClapPluginFactory,
    _host: *const c_void,
    plugin_id: *const c_char,
) -> *const ClapPlugin {
    if !crate::cstr_eq(plugin_id, PLUGIN_ID) {
        return std::ptr::null();
    }
    let facts = crate::facts();
    let mut plugin = ag_plugin::AudioGridder::new();
    let info = Plugin::info(&plugin);
    let _ = (Plugin::latency(&plugin), info.id, facts.name);
    Plugin::prepare(&mut plugin, 48_000.0, 512, 2);
    let owned = Box::new(ClapOwned {
        clap: ClapPlugin {
            desc: &DESCRIPTOR,
            plugin_data: std::ptr::null_mut(),
            init: plugin_init,
            destroy: plugin_destroy,
            activate: plugin_activate,
            deactivate: plugin_deactivate,
            start_processing: plugin_start,
            stop_processing: plugin_stop,
            reset: plugin_reset,
            process: plugin_process,
            get_extension: plugin_extension,
            on_main_thread: plugin_main,
        },
        plugin,
        scratch: [vec![0.0; 512], vec![0.0; 512]],
        prepared: 512,
        active: false,
    });
    let raw = Box::into_raw(owned);
    unsafe {
        (*raw).clap.plugin_data = raw as *mut c_void;
        &(*raw).clap
    }
}

fn owned_mut<'a>(plugin: *const ClapPlugin) -> Option<&'a mut ClapOwned> {
    if plugin.is_null() {
        return None;
    }
    unsafe {
        let data = (*plugin).plugin_data as *mut ClapOwned;
        if data.is_null() {
            None
        } else {
            Some(&mut *data)
        }
    }
}

extern "C" fn plugin_init(plugin: *const ClapPlugin) -> bool {
    let Some(owned) = owned_mut(plugin) else {
        return false;
    };
    let _ = Plugin::info(&owned.plugin);
    true
}

extern "C" fn plugin_destroy(plugin: *const ClapPlugin) {
    if plugin.is_null() {
        return;
    }
    unsafe {
        let data = (*plugin).plugin_data as *mut ClapOwned;
        if !data.is_null() {
            drop(Box::from_raw(data));
        }
    }
}

extern "C" fn plugin_activate(
    plugin: *const ClapPlugin,
    sample_rate: f64,
    _min_frames: u32,
    max_frames: u32,
) -> bool {
    let Some(owned) = owned_mut(plugin) else {
        return false;
    };
    let max_frames = (max_frames as usize).clamp(1, 8192);
    let rate = if sample_rate.is_finite() && sample_rate >= 8_000.0 {
        sample_rate as f32
    } else {
        48_000.0
    };
    Plugin::prepare(&mut owned.plugin, rate, max_frames, 2);
    for channel in &mut owned.scratch {
        channel.resize(max_frames, 0.0);
    }
    owned.prepared = max_frames;
    owned.active = true;
    let _ = Plugin::latency(&owned.plugin);
    true
}

extern "C" fn plugin_deactivate(plugin: *const ClapPlugin) {
    if let Some(owned) = owned_mut(plugin) {
        owned.active = false;
        Plugin::reset(&mut owned.plugin);
    }
}

extern "C" fn plugin_start(_plugin: *const ClapPlugin) -> bool {
    true
}

extern "C" fn plugin_stop(_plugin: *const ClapPlugin) {}

extern "C" fn plugin_reset(plugin: *const ClapPlugin) {
    if let Some(owned) = owned_mut(plugin) {
        Plugin::reset(&mut owned.plugin);
    }
}

extern "C" fn plugin_main(_plugin: *const ClapPlugin) {}

extern "C" fn plugin_extension(_plugin: *const ClapPlugin, id: *const c_char) -> *const c_void {
    if crate::cstr_eq(id, b"clap.latency") {
        &LATENCY_EXT as *const ClapLatency as *const c_void
    } else if crate::cstr_eq(id, b"clap.audio-ports") {
        &PORTS_EXT as *const ClapAudioPorts as *const c_void
    } else {
        std::ptr::null()
    }
}

extern "C" fn latency_get(plugin: *const ClapPlugin) -> u32 {
    owned_mut(plugin)
        .map(|owned| Plugin::latency(&owned.plugin) as u32)
        .unwrap_or(0)
}

extern "C" fn ports_count(_plugin: *const ClapPlugin, _is_input: bool) -> u32 {
    1
}

extern "C" fn ports_get(
    _plugin: *const ClapPlugin,
    index: u32,
    is_input: bool,
    info: *mut ClapAudioPortInfo,
) -> bool {
    if index != 0 || info.is_null() {
        return false;
    }
    unsafe {
        let slot = &mut *info;
        slot.id = 0;
        slot.name = [0; 256];
        let label: &[u8] = if is_input { b"Input" } else { b"Output" };
        slot.name[..label.len()].copy_from_slice(label);
        slot.flags = 1;
        slot.channel_count = 2;
        slot.port_type = lit(PORT_STEREO);
        slot.in_place_pair = 0;
    }
    true
}

extern "C" fn plugin_process(plugin: *const ClapPlugin, process: *const ClapProcess) -> i32 {
    let Some(owned) = owned_mut(plugin) else {
        return CLAP_PROCESS_ERROR;
    };
    if !owned.active || process.is_null() {
        return CLAP_PROCESS_CONTINUE;
    }
    let proc = unsafe { &*process };
    let frames = (proc.frames_count as usize).min(owned.prepared);
    if frames == 0 {
        return CLAP_PROCESS_CONTINUE;
    }
    for channel in &mut owned.scratch {
        channel[..frames].fill(0.0);
    }
    unsafe {
        copy_input(
            proc.audio_inputs,
            proc.audio_inputs_count,
            frames,
            &mut owned.scratch,
        );
    }
    Plugin::process(&mut owned.plugin, &mut owned.scratch, frames);
    unsafe {
        copy_output(
            proc.audio_outputs,
            proc.audio_outputs_count,
            frames,
            &owned.scratch,
        );
    }
    CLAP_PROCESS_CONTINUE
}

unsafe fn copy_input(
    buffers: *const ClapAudioBuffer,
    count: u32,
    frames: usize,
    scratch: &mut [Vec<f32>; 2],
) {
    if count == 0 || buffers.is_null() {
        return;
    }
    let buffer = &*buffers;
    if buffer.data32.is_null() {
        return;
    }
    let channels = (buffer.channel_count as usize).min(2);
    for ch in 0..channels {
        let src = *buffer.data32.add(ch);
        if src.is_null() {
            continue;
        }
        let constant = buffer.constant_mask & (1 << ch) != 0;
        if constant {
            scratch[ch][..frames].fill(*src);
        } else {
            scratch[ch][..frames].copy_from_slice(std::slice::from_raw_parts(src, frames));
        }
    }
}

unsafe fn copy_output(
    buffers: *mut ClapAudioBuffer,
    count: u32,
    frames: usize,
    scratch: &[Vec<f32>; 2],
) {
    if count == 0 || buffers.is_null() {
        return;
    }
    let buffer = &mut *buffers;
    if buffer.data32.is_null() {
        return;
    }
    let channels = (buffer.channel_count as usize).min(2);
    for ch in 0..channels {
        let dst = *buffer.data32.add(ch);
        if dst.is_null() {
            continue;
        }
        std::slice::from_raw_parts_mut(dst, frames).copy_from_slice(&scratch[ch][..frames]);
    }
}

#[no_mangle]
pub static clap_entry: ClapPluginEntry = ClapPluginEntry {
    clap_version: ClapVersion {
        major: 1,
        minor: 2,
        revision: 6,
    },
    init: entry_init,
    deinit: entry_deinit,
    get_factory: entry_get_factory,
};
