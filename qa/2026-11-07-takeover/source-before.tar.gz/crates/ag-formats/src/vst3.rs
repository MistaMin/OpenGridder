//! VST3 `GetPluginFactory`. The returned object is a static COM factory
//! (Itanium vtable: `FUnknown` then `IPluginFactory`). `FUnknown` has no
//! virtual destructor, so the vtable starts at `queryInterface`.

use std::ffi::c_void;
use std::sync::atomic::{AtomicU32, Ordering};

use openplugin::prelude::Plugin;

const K_OK: i32 = 0;
const K_NO_INTERFACE: i32 = -1;
const K_INVALID: i32 = 2;

const IID_FUNKNOWN: [u8; 16] = crate::tuid(0x0000_0000, 0x0000_0000, 0xC000_0000, 0x0000_0046);
const IID_IPLUGIN_BASE: [u8; 16] = crate::tuid(0x2288_8DDB, 0x156E_45AE, 0x8358_B348, 0x0819_0625);
const IID_IPLUGIN_FACTORY: [u8; 16] =
    crate::tuid(0x7A4D_811C, 0x5211_4A1F, 0xAED9_D2EE, 0x0B43_BF9F);
const CLASS_CID: [u8; 16] = crate::tuid(0xA11D_0A6D, 0x6E72_0001, 0x8F3C_4B21, 0xC0FF_EE01);

const K_MANY: i32 = 0x7FFF_FFFF;
const K_UNICODE: i32 = 1 << 4;

#[repr(C)]
struct PFactoryInfo {
    vendor: [u8; 64],
    url: [u8; 256],
    email: [u8; 128],
    flags: i32,
}

#[repr(C)]
struct PClassInfo {
    cid: [u8; 16],
    cardinality: i32,
    category: [u8; 32],
    name: [u8; 64],
}

const _: () = assert!(std::mem::size_of::<PFactoryInfo>() == 452);
const _: () = assert!(std::mem::size_of::<PClassInfo>() == 116);

#[repr(C)]
pub(crate) struct Factory {
    vtable: *const FactoryVtable,
}

unsafe impl Sync for Factory {}

#[repr(C)]
struct FactoryVtable {
    query_interface: unsafe extern "C" fn(*mut Factory, *const u8, *mut *mut c_void) -> i32,
    add_ref: unsafe extern "C" fn(*mut Factory) -> u32,
    release: unsafe extern "C" fn(*mut Factory) -> u32,
    get_factory_info: unsafe extern "C" fn(*mut Factory, *mut PFactoryInfo) -> i32,
    count_classes: unsafe extern "C" fn(*mut Factory) -> i32,
    get_class_info: unsafe extern "C" fn(*mut Factory, i32, *mut PClassInfo) -> i32,
    create_instance:
        unsafe extern "C" fn(*mut Factory, *const u8, *const u8, *mut *mut c_void) -> i32,
}

#[repr(C)]
struct Component {
    vtable: *const ComponentVtable,
    refs: AtomicU32,
    plugin: ag_plugin::AudioGridder,
}

#[repr(C)]
struct ComponentVtable {
    query_interface: unsafe extern "C" fn(*mut Component, *const u8, *mut *mut c_void) -> i32,
    add_ref: unsafe extern "C" fn(*mut Component) -> u32,
    release: unsafe extern "C" fn(*mut Component) -> u32,
    initialize: unsafe extern "C" fn(*mut Component, *mut c_void) -> i32,
    terminate: unsafe extern "C" fn(*mut Component) -> i32,
}

static FACTORY_VTABLE: FactoryVtable = FactoryVtable {
    query_interface: factory_query,
    add_ref: factory_add_ref,
    release: factory_release,
    get_factory_info: factory_get_info,
    count_classes: factory_count,
    get_class_info: factory_class_info,
    create_instance: factory_create,
};

static FACTORY: Factory = Factory {
    vtable: &FACTORY_VTABLE,
};

static COMPONENT_VTABLE: ComponentVtable = ComponentVtable {
    query_interface: component_query,
    add_ref: component_add_ref,
    release: component_release,
    initialize: component_initialize,
    terminate: component_terminate,
};

unsafe extern "C" fn factory_query(
    this: *mut Factory,
    iid: *const u8,
    obj: *mut *mut c_void,
) -> i32 {
    if this.is_null() || obj.is_null() {
        return K_INVALID;
    }
    *obj = std::ptr::null_mut();
    if crate::iid_eq(iid, &IID_FUNKNOWN) || crate::iid_eq(iid, &IID_IPLUGIN_FACTORY) {
        *obj = this as *mut c_void;
        factory_add_ref(this);
        K_OK
    } else {
        K_NO_INTERFACE
    }
}

unsafe extern "C" fn factory_add_ref(_this: *mut Factory) -> u32 {
    1000
}

unsafe extern "C" fn factory_release(_this: *mut Factory) -> u32 {
    1000
}

unsafe extern "C" fn factory_get_info(_this: *mut Factory, info: *mut PFactoryInfo) -> i32 {
    if info.is_null() {
        return K_INVALID;
    }
    let facts = crate::facts();
    let slot = &mut *info;
    slot.vendor = [0; 64];
    slot.url = [0; 256];
    slot.email = [0; 128];
    crate::write_cstr(&mut slot.vendor, facts.vendor);
    crate::write_cstr(&mut slot.url, facts.url);
    crate::write_cstr(&mut slot.email, facts.email);
    slot.flags = K_UNICODE;
    K_OK
}

unsafe extern "C" fn factory_count(_this: *mut Factory) -> i32 {
    let _ = crate::facts();
    1
}

unsafe extern "C" fn factory_class_info(
    _this: *mut Factory,
    index: i32,
    info: *mut PClassInfo,
) -> i32 {
    if info.is_null() {
        return K_INVALID;
    }
    if index != 0 {
        return K_INVALID;
    }
    let facts = crate::facts();
    let slot = &mut *info;
    slot.cid = CLASS_CID;
    slot.cardinality = K_MANY;
    slot.category = [0; 32];
    slot.name = [0; 64];
    crate::write_cstr(&mut slot.category, "Audio Module Class");
    crate::write_cstr(&mut slot.name, facts.name);
    K_OK
}

unsafe extern "C" fn factory_create(
    _this: *mut Factory,
    cid: *const u8,
    iid: *const u8,
    obj: *mut *mut c_void,
) -> i32 {
    if obj.is_null() {
        return K_INVALID;
    }
    *obj = std::ptr::null_mut();
    if !crate::iid_eq(cid, &CLASS_CID) {
        return K_NO_INTERFACE;
    }
    let raw = Box::into_raw(Box::new(Component::new()));
    let result = component_query(raw, iid, obj);
    component_release(raw);
    result
}

impl Component {
    fn new() -> Self {
        let mut plugin = ag_plugin::AudioGridder::new();
        let _ = Plugin::info(&plugin);
        let _ = Plugin::latency(&plugin);
        Plugin::prepare(&mut plugin, 48_000.0, 512, 2);
        Self {
            vtable: &COMPONENT_VTABLE,
            refs: AtomicU32::new(1),
            plugin,
        }
    }
}

unsafe extern "C" fn component_query(
    this: *mut Component,
    iid: *const u8,
    obj: *mut *mut c_void,
) -> i32 {
    if this.is_null() || obj.is_null() {
        return K_INVALID;
    }
    *obj = std::ptr::null_mut();
    if crate::iid_eq(iid, &IID_FUNKNOWN) || crate::iid_eq(iid, &IID_IPLUGIN_BASE) {
        *obj = this as *mut c_void;
        component_add_ref(this);
        K_OK
    } else {
        K_NO_INTERFACE
    }
}

unsafe extern "C" fn component_add_ref(this: *mut Component) -> u32 {
    if this.is_null() {
        return 0;
    }
    (*this).refs.fetch_add(1, Ordering::Relaxed) + 1
}

unsafe extern "C" fn component_release(this: *mut Component) -> u32 {
    if this.is_null() {
        return 0;
    }
    let prev = (*this).refs.fetch_sub(1, Ordering::Release);
    if prev == 1 {
        std::sync::atomic::fence(Ordering::Acquire);
        drop(Box::from_raw(this));
        0
    } else {
        prev - 1
    }
}

unsafe extern "C" fn component_initialize(this: *mut Component, _context: *mut c_void) -> i32 {
    if this.is_null() {
        return K_INVALID;
    }
    let plugin = &mut (*this).plugin;
    let _ = Plugin::info(plugin);
    Plugin::prepare(plugin, 48_000.0, 512, 2);
    let _ = Plugin::latency(plugin);
    K_OK
}

unsafe extern "C" fn component_terminate(this: *mut Component) -> i32 {
    if this.is_null() {
        return K_INVALID;
    }
    Plugin::reset(&mut (*this).plugin);
    K_OK
}

/// Steinberg module entry. Returns the static factory, never null.
#[no_mangle]
pub extern "C" fn GetPluginFactory() -> *mut Factory {
    let facts = crate::facts();
    let plugin = ag_plugin::AudioGridder::new();
    let info = Plugin::info(&plugin);
    let _ = (
        Plugin::latency(&plugin),
        info.name,
        facts.latency,
        facts.version,
    );
    &FACTORY as *const Factory as *mut Factory
}

#[no_mangle]
pub extern "C" fn bundleEntry(_bundle: *mut c_void) -> bool {
    let _ = crate::facts();
    true
}

#[no_mangle]
pub extern "C" fn bundleExit() -> bool {
    true
}
