//! Audio Unit v2 factory. `AudioComponentFactoryFunction` returns an
//! `AudioComponentPlugInInterface` whose `Open` owns an `AudioGridder`.

use std::ffi::c_void;

use openplugin::prelude::Plugin;

const NO_ERR: i32 = 0;
const ERR_INVALID_PROPERTY: i32 = -10879;
const ERR_INVALID_PROPERTY_VALUE: i32 = -10851;

const PROP_SAMPLE_RATE: u32 = 2;
const PROP_STREAM_FORMAT: u32 = 8;
const PROP_LATENCY: u32 = 12;
const PROP_MAX_FRAMES: u32 = 14;

#[repr(C)]
pub(crate) struct AudioComponentPlugInInterface {
    open: unsafe extern "C" fn(*mut c_void, *mut c_void) -> i32,
    close: unsafe extern "C" fn(*mut c_void) -> i32,
    // Lookup does not receive the instance; the host passes it to the method.
    lookup: unsafe extern "C" fn(i16) -> *const c_void,
    reserved: *mut c_void,
}

#[repr(C)]
struct AuInstance {
    interface: AudioComponentPlugInInterface,
    component: *mut c_void,
    plugin: *mut ag_plugin::AudioGridder,
    sample_rate: f64,
    max_frames: u32,
    channels: u32,
}

impl AuInstance {
    fn new() -> Self {
        let mut plugin = ag_plugin::AudioGridder::new();
        let _ = Plugin::info(&plugin);
        let _ = Plugin::latency(&plugin);
        Plugin::prepare(&mut plugin, 48_000.0, 512, 2);
        Self {
            interface: AudioComponentPlugInInterface {
                open: au_open,
                close: au_close,
                lookup: au_lookup,
                reserved: std::ptr::null_mut(),
            },
            component: std::ptr::null_mut(),
            plugin: Box::into_raw(Box::new(plugin)),
            sample_rate: 48_000.0,
            max_frames: 512,
            channels: 2,
        }
    }
}

unsafe extern "C" fn au_open(self_ptr: *mut c_void, component: *mut c_void) -> i32 {
    if self_ptr.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let au = &mut *(self_ptr as *mut AuInstance);
    au.component = component;
    if au.plugin.is_null() {
        let mut plugin = ag_plugin::AudioGridder::new();
        let _ = Plugin::info(&plugin);
        let _ = Plugin::latency(&plugin);
        Plugin::prepare(
            &mut plugin,
            au.sample_rate as f32,
            au.max_frames as usize,
            au.channels as usize,
        );
        au.plugin = Box::into_raw(Box::new(plugin));
    }
    NO_ERR
}

unsafe extern "C" fn au_close(self_ptr: *mut c_void) -> i32 {
    if self_ptr.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let au = self_ptr as *mut AuInstance;
    if !(*au).plugin.is_null() {
        drop(Box::from_raw((*au).plugin));
        (*au).plugin = std::ptr::null_mut();
    }
    drop(Box::from_raw(au));
    NO_ERR
}

unsafe extern "C" fn au_initialize(self_ptr: *mut c_void) -> i32 {
    if self_ptr.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let au = &mut *(self_ptr as *mut AuInstance);
    if au.plugin.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let rate = au.sample_rate as f32;
    let frames = au.max_frames.max(1) as usize;
    let channels = au.channels.max(1) as usize;
    Plugin::prepare(&mut *au.plugin, rate, frames, channels);
    NO_ERR
}

unsafe extern "C" fn au_uninitialize(_self_ptr: *mut c_void) -> i32 {
    NO_ERR
}

unsafe extern "C" fn au_reset(self_ptr: *mut c_void) -> i32 {
    if !self_ptr.is_null() {
        let plugin = (*(self_ptr as *mut AuInstance)).plugin;
        if !plugin.is_null() {
            Plugin::reset(&mut *plugin);
        }
    }
    NO_ERR
}

unsafe extern "C" fn au_get_property_info(
    self_ptr: *mut c_void,
    prop: u32,
    _scope: u32,
    _elem: u32,
    out_size: *mut u32,
    out_writable: *mut u8,
) -> i32 {
    if self_ptr.is_null() || (*(self_ptr as *mut AuInstance)).plugin.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let (size, writable) = match prop {
        PROP_LATENCY => (8u32, 0u8),
        PROP_SAMPLE_RATE => (8, 1),
        PROP_MAX_FRAMES => (4, 1),
        PROP_STREAM_FORMAT => (40, 1),
        _ => return ERR_INVALID_PROPERTY,
    };
    if !out_size.is_null() {
        *out_size = size;
    }
    if !out_writable.is_null() {
        *out_writable = writable;
    }
    NO_ERR
}

unsafe extern "C" fn au_get_property(
    self_ptr: *mut c_void,
    prop: u32,
    _scope: u32,
    _elem: u32,
    out_data: *mut c_void,
    io_size: *mut u32,
) -> i32 {
    if self_ptr.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let au = &mut *(self_ptr as *mut AuInstance);
    if au.plugin.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let needed: u32 = match prop {
        PROP_SAMPLE_RATE | PROP_LATENCY => 8,
        PROP_MAX_FRAMES => 4,
        PROP_STREAM_FORMAT => 40,
        _ => return ERR_INVALID_PROPERTY,
    };
    if io_size.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    if *io_size < needed || out_data.is_null() {
        *io_size = needed;
        return ERR_INVALID_PROPERTY;
    }
    match prop {
        PROP_SAMPLE_RATE => *(out_data as *mut f64) = au.sample_rate,
        PROP_LATENCY => {
            let samples = Plugin::latency(&*au.plugin) as f64;
            let rate = if au.sample_rate > 0.0 {
                au.sample_rate
            } else {
                48_000.0
            };
            *(out_data as *mut f64) = samples / rate;
        }
        PROP_MAX_FRAMES => *(out_data as *mut u32) = au.max_frames,
        PROP_STREAM_FORMAT => write_asbd(out_data, au.sample_rate, au.channels),
        _ => return ERR_INVALID_PROPERTY,
    }
    *io_size = needed;
    NO_ERR
}

unsafe extern "C" fn au_set_property(
    self_ptr: *mut c_void,
    prop: u32,
    _scope: u32,
    _elem: u32,
    in_data: *const c_void,
    in_size: u32,
) -> i32 {
    if self_ptr.is_null() || in_data.is_null() {
        return ERR_INVALID_PROPERTY_VALUE;
    }
    let au = &mut *(self_ptr as *mut AuInstance);
    match prop {
        PROP_SAMPLE_RATE if in_size >= 8 => {
            let rate = *(in_data as *const f64);
            if rate.is_finite() && rate >= 8_000.0 && rate <= 384_000.0 {
                au.sample_rate = rate;
                return NO_ERR;
            }
            ERR_INVALID_PROPERTY_VALUE
        }
        PROP_MAX_FRAMES if in_size >= 4 => {
            let frames = *(in_data as *const u32);
            if (1..=8192).contains(&frames) {
                au.max_frames = frames;
                return NO_ERR;
            }
            ERR_INVALID_PROPERTY_VALUE
        }
        PROP_STREAM_FORMAT if in_size >= 40 => {
            let rate = *(in_data as *const f64);
            let channels = *(in_data.byte_add(28) as *const u32);
            if rate.is_finite() && rate >= 8_000.0 && rate <= 384_000.0 {
                au.sample_rate = rate;
            }
            if (1..=2).contains(&channels) {
                au.channels = channels;
            }
            NO_ERR
        }
        PROP_SAMPLE_RATE | PROP_MAX_FRAMES | PROP_STREAM_FORMAT => ERR_INVALID_PROPERTY_VALUE,
        _ => ERR_INVALID_PROPERTY,
    }
}

unsafe extern "C" fn au_lookup(selector: i16) -> *const c_void {
    match selector {
        0x0001 => au_initialize as *const c_void,
        0x0002 => au_uninitialize as *const c_void,
        0x0003 => au_get_property_info as *const c_void,
        0x0004 => au_get_property as *const c_void,
        0x0005 => au_set_property as *const c_void,
        0x0009 => au_reset as *const c_void,
        _ => std::ptr::null(),
    }
}

unsafe fn write_asbd(out: *mut c_void, sample_rate: f64, channels: u32) {
    let bytes = std::slice::from_raw_parts_mut(out as *mut u8, 40);
    bytes.fill(0);
    *(out as *mut f64) = sample_rate;
    let channels = channels.max(1);
    // kAudioFormatLinearPCM = 'lpcm'
    *(out.byte_add(8) as *mut u32) = u32::from_be_bytes(*b"lpcm");
    // kAudioFormatFlagsNativeFloatPacked
    *(out.byte_add(12) as *mut u32) = 9;
    *(out.byte_add(16) as *mut u32) = 4 * channels;
    *(out.byte_add(20) as *mut u32) = 1;
    *(out.byte_add(24) as *mut u32) = 4 * channels;
    *(out.byte_add(28) as *mut u32) = channels;
    *(out.byte_add(32) as *mut u32) = 32;
}

/// Bundle factory named by `AudioComponents` → `factoryFunction`.
#[no_mangle]
pub extern "C" fn AudioComponentFactoryFunction(
    _desc: *const c_void,
) -> *mut AudioComponentPlugInInterface {
    let facts = crate::facts();
    let _ = (facts.name, facts.latency);
    let raw = Box::into_raw(Box::new(AuInstance::new()));
    unsafe { &mut (*raw).interface }
}
